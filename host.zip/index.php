<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Anton&amp;family=Kanit&amp;display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/fontawesome/css/all.css">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light" id="navbar"  style="z-index: 2">
  <a class="navbar-brand" href="#"><img src="img/logo.svg"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav m-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About us</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#">pricing</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#">Products</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="contact-us.php">Contact</a>
      </li>


    </ul>
    <form class="form-inline my-2 my-lg-0">

    </form>
  </div>
</nav>
	<header class="header">
		<div class="header-bg">
			<div class="header-info">
				<div class="container text-center text-md-left ">
					<div class="row">

						<div class="col-12 col-md-6">
							<h3>Best College <span>Hosting</span> Site For Students</h3>
							<p>Where imagination meets innovation. Unleash your creativity with us!</p>
							<a href="#">Get Started</a>

						</div>
						<div class="col-12 col-md-6">
							<div class="right-border-img">
								<img src="img/hero-drop.61ce9c00.svg">
							</div>
						</div>
						<div class="col-12">
							<div class="header-product">
								<div class="header-product-single">
									<img src="img/aws.ff261987.svg">
								</div>
								<div class="header-product-single">
									<img src="img/azure.96a92441.svg">
								</div>
								<div class="header-product-single">
									<img src="img/gcp.2b9a4457.svg">
								</div>
								<div class="header-product-single">
									<img src="img/do.c7ea70e0.svg">
								</div>
								
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
		<div class="wrap-down">
			<div class="wrap-down-div"> <i class="fa-solid fa-caret-down"></i></div>
		</div>
	</header>



</body>
<style type="text/css">
	body,html{
		width: 100%;
		height: 100%;
	}
	header{
		position: relative;
		/*background-color: linear-gradient(#edeeff, white);*/
		background-image: linear-gradient(to bottom,#edeeff, white);
		
		background-repeat: no-repeat;
		background-size: cover;
		width: 100%;
		height: 100vh;
	}
	header .header-bg{
		position: absolute;
		background-image: url(img/hero-bg-img.9a0f7af2.svg);

		
		background-repeat: no-repeat;
		background-size: cover;
		width: 100%;
		height: 100vh;

	}

	header .header-info{
		position: relative;
		top: 30%;
	}
	header h3{

	  font-size: 6rem;
	  color: black;
	  font-family: Bricolage Grotesque, sans-serif;
	  font-weight: 600;
	}
	header p{
		color: black;
	    margin-bottom: 3rem;
	    font-size: 22px;
	}
	header span{
		color: white;
	}
	header a{
		margin-top: 3rem;
		transition: 0.5s;
		padding: 20px 40px;
		border-radius: 5px;
		font-size: 20px;
		font-weight: bold;
		text-decoration: none !important;
		box-shadow: 10px 10px 30px lightblue;
transition: 0.5s;

	background-color: white;
	padding: 20px 40px;
	/*border-radius: 50px;*/
	border-radius: 5px;
	color: #253dcc;
	font-size: 20px;
	font-weight: bold;
	text-decoration: none

	}

	header .right-border-img {


	}
	header .right-border-img img{
		width: 30rem;
		filter:drop-shadow(0px 0px 57px lightblue);
		display: block;
	    margin-left: auto;
	    margin-right: auto;
	}
	nav .navbar-brand img{
		filter:drop-shadow(0px 0px 57px lightblue);
		display: block;
	    margin-left: auto;
	    margin-right: auto;

	}
	header .header-product .header-product-single{
		display: inline-block;
		margin-right: 5rem;
	}
	header .header-product{
		margin-top: 5rem;
	}
	header .header-product img{
		width: 100px;



	}
	.wrap-down{
		cursor: pointer;
		border-radius: 50%;
		border:1px solid lightblue;
		position: absolute;
		bottom: 50px;
		left: 50%;
		width: 50px;
    	height: 50px;
	}
	.wrap-down-div{
		position: relative;
	 left: 50%;
    text-align: center;
    width: 100%;
    height: 100%;
    transform: translate(-50%,-25%);
    top: 50%;
	}
	.wrap-down i{
		color: lightblue;
		font-size: 20px;
	}





@media (min-width: 576px){
	header .container{
	  max-width: 90%;
	  text-align: center !important;
	}
	

	.wave-div{
		display: block !important;
		position: absolute !important;
	}
	.waves{
		background-image: none;
	}

}
@media (min-width: 768px){
	.header-title{
		max-width: 100% !important;
	}
	header .col-md-6 {
		-ms-flex: 0 0 50%;
		flex: 0 0 100%;
		max-width: 100%;
	}
	header .container{
	  max-width: 90%;
	}
	/*.wave-div{
		position: initial !important;
	}	
	.waves{
		background-image: url('../logo2.png') !important;
	}*/
}

@media (min-width: 900px){
	header .col-md-6 {
		-ms-flex: 0 0 50%;
		flex: 0 0 100%;
		max-width: 100%;
	}
	/*.wave-div{
		position: initial !important;
	}	
	.waves{
		background-image: url('../logo2.png') !important;
	}*/
}
@media (min-width: 1500px){
	.header-title{
		max-width: 1000px !important;
	}
	header .col-md-6 {
		-ms-flex: 0 0 50%;
		flex: 0 0 50%;
		max-width: 50%;
	}

	header .container{
	  max-width: 70%;
	}



	header .container{
		text-align: left !important;
	}

	.wave-div{
		position: initial !important;
	}	
	.waves{
		background-image: url('../logo2.png') !important;
	}



}

</style>

</html>